/*
 * @Author: wfl
 * @LastEditors: wfl
 * @description: 
 * @updateInfo: 本次更新内容：
 * @Date: 2021-09-14 10:11:19
 * @LastEditTime: 2021-09-15 19:14:07
 */
declare function formatTree(data: Array<any>, param: { id: string, parentId: string, children: string, quit: any[] }): any[]