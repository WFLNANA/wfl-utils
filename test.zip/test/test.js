import { removeSpace, getType } from '../dist/wfl-utils.es.js';

console.log(removeSpace('  dsd asd as5d45 as45d4 s5ad '));

console.log(getType(123));